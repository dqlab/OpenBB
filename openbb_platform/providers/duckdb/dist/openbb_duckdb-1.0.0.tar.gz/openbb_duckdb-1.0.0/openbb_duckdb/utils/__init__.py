"""DuckDB provider utilities."""

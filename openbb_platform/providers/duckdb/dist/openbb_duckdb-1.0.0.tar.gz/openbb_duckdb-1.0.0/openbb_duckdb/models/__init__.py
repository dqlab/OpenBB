"""DuckDB provider models."""
